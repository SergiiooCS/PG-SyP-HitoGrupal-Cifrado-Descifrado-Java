package com.hito;

import java.util.Scanner;


//------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------

// AL DESENCRIPTAR, LOS ESPACIOS DEL MENSAJE LOS DETECTA COMO 'Z'. MIRAR ESO.

//------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------






public class Cesar {
    public static final String ALPHABET = "abcdefghijklmnopqrstuvwxyz ";


    //METODOS
    public static String Encriptar(String mensaje, int puestos){
        //EN CASO DE ESCRIBIR UNA MAYUSCULA, PARA EVITAR FALLOS LO CAMBIAMOS A LETRAS MINUSCULAS.
        mensaje = mensaje.toLowerCase();

        //CREAMOS UNA VARIABLE PARA GUARDAR EL MENSAJE ENCRIPTADO.
        String mensajeEncriptado = "";

        //EL BUCLE RECORRE Y CAMBIA CADA CARACTER A SU PASO DEL MENSAJE PASADO.
        for (int i = 0; i < mensaje.length(); i++){
            //RECOGEMOS LA POSICION DE CADA CARACTER DEL MENSAJE EN BASE AL ABECEDARIO.
            int pos = ALPHABET.indexOf(mensaje.charAt(i));

            //CREAMOS EL MENSAJE ENCRIPTADO EN BASE A LA POSICION ELEGIDA. GUARDAMOS EL NUEVO MENSAJE ENCRIPTADO EN UNA VARIABLE NUEVA.
            int encriptadoPos = (puestos + pos) % 26;
            char mensajeCifrado = ALPHABET.charAt(encriptadoPos);

            //AÑADIMOS EL MENSAJE ENCRIPTADO A UNA VARIABLE QUE MAS TARDE SE MOSTRARA POR CONSOLA.
            mensajeEncriptado+=mensajeCifrado;
        }//CIERRA ENCRIPTAR

        //DEVOLVEMOS EL MENSAJE ENCRIPTADO.
        return mensajeEncriptado;
    }


    public static String Desencriptar(String mensaje, int puestos){
        //COMO ANTES, CONVERTIMOS EL MENSAJE EN MINUSCULAS PARA EVITAR ERRORES.
        mensaje = mensaje.toLowerCase();

        //VARIABLE DONDE ALMACENAREMOS EL MENSAJE DESENCRIPTADO.
        String mensajeDesencriptado = "";



        //BUCLE QUE RECORRE CADA CARACTER DEL MENSAJE A DESCIFRAR.
        for (int i = 0; i < mensaje.length(); i++){

            //RECOGEMOS LA POSICION DE LOS CARACTERES DEL MENSAJE RESPETCO AL ABECEDARIO.
            int pos = ALPHABET.indexOf(mensaje.charAt(i));

            //RECOGEMOS LOS CARACTERES REALES (LOS NO ENCRIPTADOS) Y LOS ALMACENAMOS.
            int desencriptarPos = (pos - puestos) % 26;
            if (desencriptarPos < 0){
                desencriptarPos = ALPHABET.length() + desencriptarPos;
            }
            char mensajeDescifrado = ALPHABET.charAt(desencriptarPos);

            //GUARAMOS EL MENSAJE DESENCRIPTADO EN UNA VARIABLE LA CUAL SE MOSTRARA MAS TARDE POR CONSOLA.
            mensajeDesencriptado+=mensajeDescifrado;
        }
        //MOSTRAMOS EL RESULTADO.
        return mensajeDesencriptado;
    }//CIERRA DESENCRIPTAR
}//CIERRA CLASE
