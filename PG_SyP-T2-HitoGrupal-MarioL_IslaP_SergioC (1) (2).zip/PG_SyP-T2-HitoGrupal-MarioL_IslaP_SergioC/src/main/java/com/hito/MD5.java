package com.hito;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Scanner;



// ------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------


                    // COSAS QUE HACER

/*
- REGISTRAR CORREO Y CONTRASEÑA EN UN FICHERO.
        ENCRIPTAS EL CORREO Y LA CONTRASEÑA.

- INICIAR SESION MEDIANTE EL CORREO Y CONTRASEÑA.
        CORREO LO ENCRIPTAMOS A MD5 -> COMPARAMOS EL HASH ALMACENADO EN EL FICHERO MEDIANTE ALGUNA CLAVE (NOMBRE, CORREO, ETC)
        CORREO LO ENCRIPTAMOS A MD5 -> COMPROBAMOS SI HAY ALGUN HASH IGUAL QUE EL GENERADO, SI LO HAY INICIA SESION, SI NO LO HAY USUARIO INCORRECTO.
*/

//------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------



public class MD5 {
    public static String EncriptarCorreo() throws NoSuchAlgorithmException {
        //CREAMOS SCANNER PARA LEER EL MENSAJE QUE EL USUARIO QUIERE CIFRAR POR CONSOLA.
        Scanner sc = new Scanner(System.in);

        //RECOGEMOS LA ENTRADA POR TECLADO DEL USUARIO Y SU MENSAJE.
        System.out.println("Introduce el correo que desea cifrar: ");
        String correo = sc.nextLine();

        //CLASE 'MessageDigest' ES UNA CLASE QUE IMPORTAMOS E UTILIZA ENCRIPTACION Y DESENCRIPTACION CON ALGORITMOS COMO 'SHA1' Y 'MD5'.
        //CON EL METODO 'getInstance' ESPECIFICAMOS EL ALGORITMO QUE QUEREMOS UTILIZAR.
        MessageDigest md = null;
        try {
            md = MessageDigest.getInstance("MD5");
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }

        //ALMACENAMOS EL MENSAJE INTRODUCIDO DEL USUARIO EN EL OBJETO 'md' DE LA CLASE 'MessageDirect'.
        md.update(correo.getBytes());

        //EL METODO 'digest()' CALCULA LA FUNCION 'HASH' DEL CONTENIDO DE 'md', ES DECIR, DEL MENSAJE INTRODUCIDO POR CONSOLA.
        byte[] digest = md.digest();

        //STRINGBUFFER LO UTILIZAMOS PARA GUARDAR EN MEMORIA LOS DATOS DE LA OPERACION.
        StringBuffer sb = new StringBuffer();

        //POR CADA BYTE DE MENSAJE CREAMOS UN CARACTER.
        for (byte b : digest) {
            sb.append(String.format("%02x", b & 0xff));
        }

        //PINTAR LOS RESULTADOS POR CONSOLA.
        //System.out.println("Contraseña original: " + correo);
        //System.out.println("Correo encriptado: " + sb.toString());
        String resultadoCorreo=sb.toString();
            return resultadoCorreo;
    }//CIERRA ENCRIPTARCORREO
    public static String EncriptarPass() throws NoSuchAlgorithmException {
        //CREAMOS SCANNER PARA LEER EL MENSAJE QUE EL USUARIO QUIERE CIFRAR POR CONSOLA.
        Scanner sc2 = new Scanner(System.in);

        //RECOGEMOS LA ENTRADA POR TECLADO DEL USUARIO Y SU MENSAJE.
        System.out.println("Introduce la contraseña que desea cifrar: ");
        String pass = sc2.nextLine();

        //CLASE 'MessageDigest' ES UNA CLASE QUE IMPORTAMOS E UTILIZA ENCRIPTACION Y DESENCRIPTACION CON ALGORITMOS COMO 'SHA1' Y 'MD5'.
        //CON EL METODO 'getInstance' ESPECIFICAMOS EL ALGORITMO QUE QUEREMOS UTILIZAR.
        MessageDigest md = null;
        try {
            md = MessageDigest.getInstance("MD5");
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }

        //ALMACENAMOS EL MENSAJE INTRODUCIDO DEL USUARIO EN EL OBJETO 'md' DE LA CLASE 'MessageDirect'.
        md.update(pass.getBytes());

        //EL METODO 'digest()' CALCULA LA FUNCION 'HASH' DEL CONTENIDO DE 'md', ES DECIR, DEL MENSAJE INTRODUCIDO POR CONSOLA.
        byte[] digest = md.digest();

        //STRINGBUFFER LO UTILIZAMOS PARA GUARDAR EN MEMORIA LOS DATOS DE LA OPERACION.
        StringBuffer sb = new StringBuffer();

        //POR CADA BYTE DE MENSAJE CREAMOS UN CARACTER.
        for (byte b : digest) {
            sb.append(String.format("%02x", b & 0xff));
        }

        //PINTAR LOS RESULTADOS POR CONSOLA.
        //System.out.println("Contraseña original: " + pass);
        //System.out.println("Contraseña encriptada: " + sb.toString());
        String resultadoPass=sb.toString();
        return resultadoPass;
    }//CIERRA ENCRIPTAR
}//CIERRA CLASE