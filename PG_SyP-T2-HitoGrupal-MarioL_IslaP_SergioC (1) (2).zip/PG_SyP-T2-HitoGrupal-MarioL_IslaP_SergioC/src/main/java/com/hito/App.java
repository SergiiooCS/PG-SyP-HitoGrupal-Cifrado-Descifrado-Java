package com.hito;

import java.io.*;
import java.nio.file.Path;
import java.security.NoSuchAlgorithmException;
import java.util.Scanner;
import java.nio.file.Files;

public class App{
    public static void main( String[] args ) throws IOException, NoSuchAlgorithmException {
        Scanner sc=new Scanner(System.in);
        String opcion="";


        do{
            // MENU PARA QUE EL USUARIO ELIJA LA OPCION QUE QUIERE.
            System.out.println("----------------------------------------------------");
            System.out.println("ELIJE UNA DE LAS SIGUIENTES OPCIONES (1-2-3-4-5-6):");
            System.out.println("1 : Cifrado 'Cesar'");
            System.out.println("2 : Cifrado 'MD5'");
            System.out.println("3 : Cifrado 'SHA'");
            System.out.println("4 : Iniciar sesion MD5");
            System.out.println("5 : Iniciar sesion SHA");
            System.out.println("6 : Salir del programa");

            // LEEMOS LA OPCION ELEGIDA POR EL USUARIO.
            opcion= sc.nextLine();

            // SCANNERS PARA LEER LOS MENSAJES Y LOS PUESTOS A CAMBIAR.
            Scanner mensajeSC=new Scanner(System.in);
            Scanner puestosSC=new Scanner(System.in);
                switch (opcion) {
                    case "1":
                        File fichero;

                        // LEER OPCIONES DEL USUARIO.
                        Scanner nombreFichero = new Scanner(System.in);
                        System.out.println("Dime el mensaje a cifrar : ");
                        String mensajeCesar = mensajeSC.nextLine();
                        System.out.println("Dime el mensaje a cifrar : ");
                        int puestosCesar = puestosSC.nextInt();

                        // REALIZAR LOS METODOS DE CIFRADO.
                        Cesar cs = new Cesar();
                        System.out.println("Mensaje cifrado : ");
                        System.out.println(cs.Encriptar(mensajeCesar, puestosCesar));


                        // GUARDAR EL RESULTADO EN UN FICHERO.
                        // GUARDAR EL 'RETURN' DEL METODO 'ENCRIPTAR' EN UNA VARIABLE PARA MAS TARDE ALMACENARLA EN UN FICHERO.
                        String MensajeCifradoCesar = cs.Encriptar(mensajeCesar, puestosCesar);
                        // PREGUNTAMOS AL USUARIO POR EL NOMBRE DEL FICHERO.
                        System.out.println("Dime el nombre del fichero : ");
                        String nombreFich = nombreFichero.nextLine();
                        // CREAMOS EL FICHERO PARA EL CIFRADO CESAR.
                        fichero = new File(nombreFich + ".txt");
                        // GRABAMOS EL MENSAJE CIFRADO EN EL FICHERO
                        FileWriter fw = new FileWriter(fichero);
                        fw.write(MensajeCifradoCesar);
                        System.out.println("Mensaje guardado");
                        // CERRAMOS EL FICHERO.
                        fw.close();


                        //DESCIFRAR EL MENSAJE INTRODUCIDO.
                        System.out.println("Mensaje descifrado : ");
                        System.out.println(cs.Desencriptar(cs.Encriptar(mensajeCesar, puestosCesar), puestosCesar));
                        break;


                    case "2":
                        fichero = new File("CifradoMD5.txt");


                        // REALIZAR LOS METODOS DE CIFRADO.
                        MD5 md = new MD5();

                        //GUARDAMOS RESULTADOS EN UN ARCHIVO.
                        // GUARDAR EL 'RETURN' DEL METODO 'EncriptarCorreo' y 'EncriptarPass' EN UNA VARIABLE PARA MAS TARDE ALMACENARLA EN UN FICHERO.
                        String correoCifrado = md.EncriptarCorreo();
                        String passCifrado = md.EncriptarPass();


                        // GRABAMOS EL MENSAJE CIFRADO EN EL FICHERO.
                        FileWriter fw2 = new FileWriter(fichero);
                        fw2.write(correoCifrado + "-");
                        fw2.write(passCifrado + "\n");
                        System.out.println("Datos del usuario guardados");
                        // CERRAMOS EL FICHERO.
                        fw2.close();
                        break;

                    case "3":
                        fichero = new File("CifradoSHA.txt");

                        // REALIZAR LOS METODOS DE CIFRADO.
                        SHA sha = new SHA();

                        //GUARDAMOS RESULTADOS EN UN ARCHIVO.
                        // GUARDAR EL 'RETURN' DEL METODO 'EncriptarCorreo' y 'EncriptarPass' EN UNA VARIABLE PARA MAS TARDE ALMACENARLA EN UN FICHERO.
                        String correoCifradoSha = sha.EncriptarCorreoSha();
                        String passCifradoSha = sha.EncriptarPassSha();


                        // CREAMOS EL FICHERO PARA EL CIFRADO CESAR.
                        FileWriter fw3 = new FileWriter(fichero);
                        fw3.write(correoCifradoSha + "-");
                        fw3.write(passCifradoSha + "\n");
                        System.out.println("Datos del usuario guardados");
                        // CERRAMOS EL FICHERO.
                        fw3.close();

                        System.out.println("Datos del usuario guardados");
                        // CERRAMOS EL FICHERO.
                        break;

                    case "4":
                        File ficheroMd5 = new File("CifradoMD5.txt");
                        Scanner lectorFich = new Scanner(ficheroMd5);

                        //CIFRAR EL DATO PASADO PARA LA COMPROBACION DE ESTE.
                        MD5 md2 = new MD5();
                        String comprobarCorreoMD5 = md2.EncriptarCorreo();
                        String comprobarPassMD5 = md2.EncriptarPass();

                        String comprobacionMD5 = comprobarCorreoMD5 + "-" + comprobarPassMD5;

                        //BUCLE QUE RECORRE EL CONTENIDO DEL FICHERO.
                        while (lectorFich.hasNextLine()) {
                            String linea = lectorFich.nextLine();
                            if (comprobacionMD5.equals(linea)) {
                                System.out.println("Bienvenido, has inciado sesion");
                                break;
                            } else {
                                System.out.println("Usuario no encontrado");
                            }
                        }
                        lectorFich.close();
                        break;

                    case "5":
                        File ficheroSHA = new File("CifradoSHA.txt");
                        Scanner lectorFich2 = new Scanner(ficheroSHA);

                        //CIFRAR EL DATO PASADO PARA LA COMPROBACION DE ESTE.
                        SHA sha2 = new SHA();
                        String comprobarCorreoSHA = sha2.EncriptarCorreoSha();
                        String comprobarPassSHA = sha2.EncriptarPassSha();
                        String comprobacionSHA = comprobarCorreoSHA + "-" + comprobarPassSHA;

                        //BUCLE QUE RECORRE EL CONTENIDO DEL FICHERO.
                        while (lectorFich2.hasNextLine()) {
                            String linea2 = lectorFich2.nextLine();
                            if (comprobacionSHA.equals(linea2)) {
                                System.out.println("Bienvenido, has inciado sesion");
                                break;
                            } else {
                                System.out.println("Usuario no encontrado");
                            }
                        }
                        lectorFich2.close();
                        break;

                    case "6":
                        System.out.println("Cerrando el programa");
                        break;

                    default:
                        System.out.println("Opcion incorrecta. Elija una opcion entre 'cesar'-'md5'-'sha'");
                        break;
                }//CIERRA SWITCH
            } while (!opcion.equals("6"));
    }//CIERRA MAIN
}//CIERRA CLASS
