package com.hito;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Scanner;

public class SHA {
    public static String EncriptarCorreoSha() throws NoSuchAlgorithmException {
        //CREAMOS SCANNER PARA LEER EL MENSAJE QUE EL USUARIO QUIERE CIFRAR POR CONSOLA.
        Scanner sc = new Scanner(System.in);

        //RECOGEMOS LA ENTRADA POR TECLADO DEL USUARIO Y SU MENSAJE.
        System.out.println("Introduce el correo que desea cifrar: ");
        String correoSha = sc.nextLine();

        //CLASE 'MessageDigest' ES UNA CLASE QUE IMPORTAMOS E UTILIZA ENCRIPTACION Y DESENCRIPTACION CON ALGORITMOS COMO 'SHA1' Y 'MD5'.
        //CON EL METODO 'getInstance' ESPECIFICAMOS EL ALGORITMO QUE QUEREMOS UTILIZAR.
        MessageDigest md = MessageDigest.getInstance("SHA-1");

        //ALMACENAMOS EL MENSAJE INTRODUCIDO DEL USUARIO EN EL OBJETO 'md' DE LA CLASE 'MessageDirect'.
        md.update(correoSha.getBytes());


        //EL METODO 'digest()' CALCULA LA FUNCION 'HASH' DEL CONTENIDO DE 'md', ES DECIR, DEL MENSAJE INTRODUCIDO POR CONSOLA.
        byte[] digest = md.digest();

        //STRINGBUFFER LO UTILIZAMOS PARA GUARDAR EN MEMORIA LOS DATOS DE LA OPERACION.
        StringBuffer sb = new StringBuffer();

        //POR CADA BYTE DE MENSAJE CREAMOS UN CARACTER.
        for (byte b : digest) {
            sb.append(String.format("%02x", b & 0xff));
        }

        //PINTAR LOS RESULTADOS POR CONSOLA.
        //System.out.println("Mensaje original: " + mensajesha);
        String resultadoCorreoSha=sb.toString();
        return resultadoCorreoSha;
    }//CIERRA EncriptarCorreoSha



    public static String EncriptarPassSha() throws NoSuchAlgorithmException {
        //CREAMOS SCANNER PARA LEER EL MENSAJE QUE EL USUARIO QUIERE CIFRAR POR CONSOLA.
        Scanner sc2 = new Scanner(System.in);

        //RECOGEMOS LA ENTRADA POR TECLADO DEL USUARIO Y SU MENSAJE.
        System.out.println("Introduce la contraseña que desea cifrar: ");
        String passSha = sc2.nextLine();

        //CLASE 'MessageDigest' ES UNA CLASE QUE IMPORTAMOS E UTILIZA ENCRIPTACION Y DESENCRIPTACION CON ALGORITMOS COMO 'SHA1' Y 'MD5'.
        //CON EL METODO 'getInstance' ESPECIFICAMOS EL ALGORITMO QUE QUEREMOS UTILIZAR.
        MessageDigest md = MessageDigest.getInstance("SHA-1");

        //ALMACENAMOS EL MENSAJE INTRODUCIDO DEL USUARIO EN EL OBJETO 'md' DE LA CLASE 'MessageDirect'.
        md.update(passSha.getBytes());


        //EL METODO 'digest()' CALCULA LA FUNCION 'HASH' DEL CONTENIDO DE 'md', ES DECIR, DEL MENSAJE INTRODUCIDO POR CONSOLA.
        byte[] digest = md.digest();

        //STRINGBUFFER LO UTILIZAMOS PARA GUARDAR EN MEMORIA LOS DATOS DE LA OPERACION.
        StringBuffer sb = new StringBuffer();

        //POR CADA BYTE DE MENSAJE CREAMOS UN CARACTER.
        for (byte b : digest) {
            sb.append(String.format("%02x", b & 0xff));
        }

        //PINTAR LOS RESULTADOS POR CONSOLA.
        //System.out.println("Mensaje original: " + mensajesha);
        String resultadoPassSha=sb.toString();
        return resultadoPassSha;
    }//CIERRA EncriptarPassSha

}//CIERRA CLASE
